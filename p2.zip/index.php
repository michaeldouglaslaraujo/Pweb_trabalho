<?php
	session_start();
	if(isset($_SESSION["codigo_aluno"])==false)
	{
		header("location:login.php");
	}
	$sqli = "codigo=".$_SESSION["codigo_aluno"];
	?>


<!DOCTYPE html>
<html lang="en">
	
<head>
  <meta charset="utf-8"> <!-- Correção de Caracteres Especiais -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="Formulário de Submissão de Atividade" content="">
  <meta name="Michael Araújo" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="../css/sb-admin.css" rel="stylesheet">
  <!-- Incluse JQuery--> 
  <script src="../gulpfile.js"></script>
</head>

	<!-- Formulário de Submissão de Atividade -->

<body class="bg-dark">
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Submissão de Trabalho</div>
      <div class="card-body">
        <form>
          <div class="form-group">
            <div class="form-row">
              

                <label for="nomeCurso">Curso</label>

				<select class="form-control"  id="nomeCurso" type="text" aria-describedby="cursoHelp" placeholder="Escolha o Curso!" name="Curso" required onClick="mudar();">
					<option value="0"> Nenhum menu relacionado</option>
					
						<?php
							
							$conexao = mysqli_connect("baratheon0001.hospedagemdesites.ws","norto_fatecig","freiJoao59","norton_fatecig");
							$sql = "select codigo, nomeCurso from curso where status=1";
							$result = mysqli_query($conexao, $sql);
							while ($registro = @mysqli_fetch_array($result)) 
							{
								$codigo = $registro ["codigo"];
								$nomeCurso = $registro ["nomeCurso"];
								echo"<option value='$codigo'> $nomeCurso </option>";
							}					
						?>
				
					
				</select>              
            </div>
          </div>
          
		  <div class="form-group">
            <label for="trabalho">Turma</label>
				<select class="form-control" id="turma" type="text" aria-describedby="textoHelp" placeholder="Escolha a Turma!" name="turma" required>

					<option value="0"> Nenhum menu relacionado</option>
						
						<?php
							$conexao = mysqli_connect("baratheon0001.hospedagemdesites.ws","norto_fatecig","freiJoao59","norton_fatecig");
							$sql = "select codigo, titulo from turma WHERE codigo>=1";
							$result = mysqli_query($conexao, $sql);
							while ($registro = @mysqli_fetch_array($result))
							{
								$codigo = $registro ["codigo"];
								$titulo = $registro ["titulo"];
								echo"<option value='$codigo'> $titulo </option>";
							}					
					?>
		  </select>              
          </div>
		  <div class="form-group">
            <label for="trabalho">Trabalho</label>
				<select class="form-control" id="nomeTrabalho" type="text" aria-describedby="textoHelp" placeholder="Escolha o trabalho a ser submetido!" name="nomeTrabalho" required>

					<option value="0"> Nenhum menu relacionado</option>
						
						<?php
						
							$conexao = mysqli_connect("baratheon0001.hospedagemdesites.ws","norto_fatecig","freiJoao59","norton_fatecig");
							$sql = "select codigo, titulo, descritivo, dtFim from atividade where status>=1";
							$result = mysqli_query($conexao, $sql);
							while ($registro = @mysqli_fetch_array($result)) 
							{
								$codigo = $registro ["codigo"];
								$titulo = $registro ["titulo"];
								$descritivo = $registro ["descritivo"];
								$dtFim = $registro ["dtFim"];
								echo"<option value='$codigo'> $titulo </option>";
							}
						?>
					
				</select>              
          </div>
          
		  <div class="form-group">  
					<label for="DescricaoAtividade">Descrição da Atividade</label></br>
					<label class="d-block small mt-3" for="DescAtividade" id="DescAtividade">
					
						<?php
						
							$conexao = mysqli_connect("baratheon0001.hospedagemdesites.ws","norto_fatecig","freiJoao59","norton_fatecig");
							$sql = "select codigo, titulo, descritivo, dtFim from atividade where status=1";
							$result = mysqli_query($conexao, $sql);
							while ($registro = @mysqli_fetch_array($result)) 
							{
								$codigo = $registro ["codigo"];
								$titulo = $registro ["titulo"];
								$descritivo = $registro ["descritivo"];
								$dtFim = $registro ["dtFim"];
								echo"<option value='$codigo'> $descritivo </option>";
							}
							
						?>
</label>
		  
		  <div class="form-group">  
			<div class="form-row">

					<label for="DataDeEntregaLimite">Data limite para Submissão </label></br>
					<label label class="d-block small mt-3" for="HorarioLimite" id="HorarioLimite" value = "0">
					
							<?php
							
							$con = mysqli_connect("baratheon0001.hospedagemdesites.ws","norto_fatecig","freiJoao59","norton_fatecig");
							$sql = "select codigo, dtFim from atividade where status>=1";
							$result = mysqli_query($conexao, $sql);
							while ($registro = @mysqli_fetch_array($result)) 
							{
								$codigo = $registro ["codigo"];
								$titulo = $registro ["titulo"];
								$descritivo = $registro ["descritivo"];
								$dtFim = $registro ["dtFim"];
								echo"<option value='$codigo'> $dtFim </option>";
							}
						
							?>
					</label>
   
				</div>
			
		  
		   <div class="form-group">  
					<label for="UrlTrabalho">URL do Trabalho (OneDrive, Drive, ...) </label>
					<input class="form-control" id="UrlTrabalho" type="Url" aria-describedby="uploadHelp" name="UrlTrabalho" required>          
				</div>
				
          </div>
          
		  <input class="btn btn-primary btn-block" type="submit" value="Submeter"/>
<?php


$con = mysqli_connect("baratheon0001.hospedagemdesites.ws","norto_fatecig","freiJoao59","norton_fatecig");

$StrSQL= "INSERT INTO atividadeentrega(codigoAtividade, codigoAluno, dataEntrega, urlEntrega) VALUES(";

	$codigoAtividade = $_POST['codigoAtividade'];
	$codigoAluno = $_POST['codigo'];
	$dataEntrega = $_POST['CURRENT_TIME()'];
	$urlEntrega = $_POST['UrlTrabalho'];

	mysqli_query($con,"INSERT INTO `atividadeentrega` (`codigoAtividade`, `codigoAluno`, `dataEntrega`, `urlEntrega`) VALUES ('$codigoAtividade', '$codigo', '$dataEntrega', '$urlEntrega')");
   

echo "Trabalho cadastrado";
mysqli_close($con);	
?>

        </form>
		
				
        <div class="text-center">
          <a class="d-block small mt-3" href="faq.html">Dúvidas</a> 
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>

</html>

 
<script lang="javascript" src="jquery-3.3.1.min.js"></script>
<script lang="javascript">

    $(document).ready(function () 
	{                

        $("#turma").change(function () 
		{
           $("#nomeTrabalho").load("listaAtividades.php", 
		   { 
				turma: $(this).val() 
		   });
	    });

    });    

</script>